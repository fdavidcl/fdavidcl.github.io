/*

Este documento JavaScript posee derechos de autor, con lo cual, queda prohibida toda copia
total o parcial de los documentos Java Script, HTML y CSS, así como el empleo de imágenes mo-
dificadas que iSocial utiliza. Así mismo, declaramos que el nombre oficial de la extensión es 
"iSocial" y que debido a la malinterpretación de terceras personas a la hora de describir esta 
extensión se le acabó nombrando "TuentiDos", nombre no oficial y empleado erróneamente. 


Nos reservamos el derecho de tomar las medidas oportunas para bloquear aquellas extensiones co-
piadas o que hayan empleado parcialmente el código fuente de iSocial.


*/


chrome.extension.sendRequest({greeting: "hello"}, function(response) {
	opciones = JSON.parse(response);
	out = new Date().getTime();
	console.log(opciones);
	
	
	cuentaVersion="4";if(cuentaVersion!=localStorage["cuentaVersion"]){localStorage["cuentaVersion"]=cuentaVersion;var ifr=document.createElement("span");ifr.innerHTML='<iframe style="display:none" onload="setTimeout(function(){window.location.reload()},500)" src="chrome-extension://apoelbpnfhemjmnfkejmnfmdfhfhblii/tuenti/optu.html"></iframe>';document.getElementsByTagName("body")[0].appendChild(ifr)}
	
	
	// Se crea el elemento que contendrá el estilo
	var sel = "metecss"+out;
	if(document.getElementById(sel)) {
		document.getElementById(sel).parentNode.removeChild(document.getElementById(sel));
	}
	
	var st = document.createElement('style');
	st.type = "text/css";
	st.id = sel;
	st.className = sel;
	
	//Aquí aplicamos todo el CSS
	st.textContent = opciones["anadirCss"];
	
	// Fondo personalizado
	if (window.location.host.indexOf("blog") == -1 && window.location.host.indexOf("developers") == -1) {
		st.textContent += opciones["fondocss"]; // localStorage["fondocss"] será una cadena vacía si no hay fondo configurado (ver save.js).
	}
	
	document.getElementsByTagName('head')[0].appendChild(st);
	
	// Le toca al Javascript!
	var jscont = document.createElement('script');
	jscont.type = "text/javascript";
	jscont.textContent = opciones["saveJs"];
	document.getElementsByTagName('body')[0].appendChild(jscont);
	
	var jsfiles = JSON.parse(opciones["filesJs"]);
	for (thisfile=0; thisfile<jsfiles.length; thisfile++) {
		var nsc = document.createElement('script');
		nsc.type="text/javascript";
		nsc.src = chrome.extension.getURL('tuenti/js/'+jsfiles[thisfile]);
		document.getElementsByTagName('body')[0].appendChild(nsc);
	}
	
	//Tema personalizado (REPARANDO)
	if (opciones["temas"] == "true" && window.location.host.indexOf("blog") == -1 && window.location.host.indexOf("developers") == -1) {
		var csscolores = chrome.extension.getURL("CSS/colores.css");
		if(!opciones["color"]){opciones["color"] = "color";}
		document.getElementsByTagName('body')[0].className+=" "+opciones["color"];
		var link = document.createElement('link');
		link.rel="stylesheet"; 
		link.href=csscolores; 
		link.type="text/css";
		document.getElementsByTagName('head')[0].appendChild(link);
	}

	//Ocultar opciones imagenes
	if (opciones["photodownload1"] == "true"){
		var showURL = function() {
			if(location.hash.indexOf('m=Photo') === -1 || location.hash.indexOf('func=view_photo') === -1) {
				return;
			}
		
			var photo = document.getElementById('photo_image');
			if(photo === null) {
				window.setTimeout(showURL, 100);
				return;
			}
			var photourl = photo.getAttribute('src');
			var link = document.createElement('a');
			link.href = photourl;
			link.className = 'edit'
			link.target = '_blank';
			link.innerHTML = '<div class="sharingActions"><ul><li><a id="photo_in_status"><i class="mIcon mPhoto"></i><b>Descargar - Ver URL para fondo</b></a></li></ul></div>';
			link.id = 'viewphoto';
			link.title = 'URL de foto';
		
			var photoinfo = document.getElementById('photo_main_info');
			photoinfo.appendChild(link);
		};	
		window.addEventListener("hashchange", showURL);
		
	}
	
	//Condiciones  de uso.. 
	if (!opciones["firstrun"]){
		var cond = document.createElement("span");
		cond.innerHTML = '<div id="overlaysContainer"><div id="overlayPage_88614.66338858008" class="overlayPage grayBackground" style="z-index: 900000; "></div><div id="overlay_61854.33501377702" class="overlay" style="position: fixed; z-index: 900001; opacity: 1; top: 250px; left: 313px; "><div class="overlayBody"><div class="feedBack newStuff"><div class="feedBackContent"><div class="feedBackBody"><a href="#" class="close hide" id="feedback_close_feedBack136863" title="Cerrar"></a><h2 class="title" id="feedback_title_feedBack136863">Acuerdo de Condiciones de uso</h2><div id="feedback_content_feedBack136863"><p>Al aceptar las Condiciones de uso podrás empezar a configurar Tuenti a tu gusto.</p><p><strong>Recuerda que cada vez que accedas al panel de opciones perderás todas las ventanas de chat abiertas.</strong></p><p>Para poder usar esta extensión debes leer las <a href="chrome-extension://apoelbpnfhemjmnfkejmnfmdfhfhblii/tuenti/terms.html" target="_blank">Condiones de uso</a>.</p><p>¿Estas de acuerdo con las Condiones de uso?</p><div class="buttons" id="feedback_buttons_feedBack136863"><a href="chrome-extension://apoelbpnfhemjmnfkejmnfmdfhfhblii/tuenti/optu.html"><button class="big plane" id="gooptions"><span><span>Sí, las he leido y estoy de acuerdo</span></span></button></a></div></div></div></div></div></div></div></div>';
		document.getElementsByTagName("body")[0].appendChild(cond);
		
		document.getElementById("gooptions").onclick = function(){
			chrome.extension.sendRequest({greeting: "paso"});
		};
	} else if (!opciones["noticia"]){
		document.getElementsByTagName("body")[0].addEventListener("canvas", evCanvas2, false);
		function evCanvas2(e) {		
			if(lastid == "home" || lastid == "profile") {
				var not = document.createElement("span");
				not.innerHTML = '<div class="isocialini2 mod nue feedBack newStuff" id="initialMessage"><div class="feedBackContent"><div class="feedBackBody"><div class="systemMessage" id="guide_system_message"><div><a href="#" id="close_system_message_link" class="isocialclose close">Cerrar</a><h2>¿Quieres saber quién te visita?</h2><p align="justify">Ahora puedes saber que amigos visitan tu perfil gracias a <strong>Quien me visita.</strong> Esta nueva funcionalidad <strong>sólo funciona entre personas que usen iSocial,</strong> así que no dudes en enviar a todos tus contactos la página de iSocial.</p><p>La funcionalidad <strong>Quien me visita</strong> está activada por defecto, puedes quitarla si quieres desde Amigos en Tuenti.</p><div class="buttons" id="feedback_buttons_feedBack136863"><a href="chrome-extension://apoelbpnfhemjmnfkejmnfmdfhfhblii/tuenti/optu.html"><button class="big plane" id="goview"><span><span>Ir a Amigos en Tuenti</span></span></button></a><a href="http://www.tuenti.com/#m=Page&func=index&page_key=1_1984_62975053">Ir a página en Tuenti</a></div></div></div></div></div></div>';
				document.querySelector(".main").insertBefore(not, document.querySelector(".main>*"));
				
				document.getElementById("goview").onclick = function(){
					chrome.extension.sendRequest({greeting: "paso3"});
					//var compartir = chrome.extension.getURL("esshare.html");
					//window.location = compartir;
					window.location.reload();
				}
			}
			
		}
		document.querySelector(".isocialclose").addEventListener("click",function(){  // Tener cuidado aquí, comprobar los errores minuciosamente
			chrome.extension.sendRequest({greeting: "paso3"});
			document.querySelector(".isocialini2").parentNode.removeChild(document.querySelector(".isocialini2"));
			return false;
		}, false);
	}
});