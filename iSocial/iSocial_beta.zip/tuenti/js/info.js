//Cargador panel lateral
var media = document.createElement("div"); 
media.id = "media";
media.className = "mod feedBack waiting"; 
media.innerHTML = '<div class="feedBackContent"><div class="feedBackBody"><p>Realizando cambios y mejorando funciones.<br><strong>Gracias por tu paciencia.</strong></p></div></div>';  
setInterval(function() {if (!document.getElementById("media") && location.href.indexOf("m=Home")>-1) {  document.getElementsByClassName("left")[0].appendChild(media);}}, 150);

