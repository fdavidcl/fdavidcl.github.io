var palnombre = setInterval(function catchName(){
        if(document.getElementById('home_user_name')){
                n = document.getElementById('home_user_name').innerHTML.split(' ').shift();
                var myName = n[0];
                for (i=1;i<n.length;i++) {
                        myName += " "+n[i];
                }
                localStorage["myName"]=myName;
                clearInterval(palnombre);
        }
},100);
 
var loca;
 
window.onhashchange = function ifProfile(){
        if (loca!==location.href && location.hash.indexOf('m=Profile')>-1 && !document.getElementById('add_blog_entry_button') && localStorage["myName"] && localStorage["myName"]!=="") {
                loca = location.href;
               
                visitado = loca.split("user_id=")[1].split("&")[0];
                visit1 = document.head.innerHTML.match(/VIEWER_ID = '([^']*)/);
        idVisitante = visit1[1];
                hoy = new Date();
                ahora = hoy.getHours()+":"+hoy.getMinutes()+" "+hoy.getDate()+"/"+hoy.getMonth();
               
                var URL = "http://isocial.webcindario.com/index.php?a="+visitado+"&b="+idVisitante+"&c="+nameVisitante+"&d="+ahora;
                URLFinal = encodeURI(URL);
               
                conexion1=new XMLHttpRequest(); // Como iSocial es solo para Chrome, no necesitamos comprobar que soporte XMLHttpRequest.
                conexion1.open('GET',URLFinal, true);
                conexion1.send();
        }
};

//Suprimido <input type="button" class="button" id="cerrarVisitasGente" value="Cerrar visitas" onclick="cerrarVerVisitas()" style="width:100px;display:none; position:fixed; left:10px; top:50px; z-index: 90000001"></input> 
var botonVisits = document.createElement('div');
botonVisits.innerHTML='<input type="button" class="button" id="verVisitasGente" value="Ver visitas" onclick="verVisitas()" style="width:100px;position:fixed; left:10px; top:50px; z-index: 90000001"><script type="text/javascript"></script><style>.button{margin: 0;padding: 0;display: inline-block;zoom: 1;vertical-align: middle;position: relative;text-align: center;cursor: pointer;border: 1px solid #CCC;-webkit-border-radius: 3px;border-radius: 3px;	display: block;	background: -webkit-gradient(linear,left bottom,left top,color-stop(0,#E2E2E2),color-stop(1,#FEFFFE)); color: #666;font-size: 11px;font-family: \'Lucida Grande\',Arial,Helvetica,sans-serif;text-align:center;text-shadow: 0 1px 0 white;font-size: 12px;height:28px;}                                                                                                                                                   .button:hover{margin: 0;padding: 0;display: inline-block;zoom: 1;vertical-align: middle;position: relative;text-align: center;cursor: pointer;border: 1px solid #CCC;-webkit-border-radius: 3px;border-radius: 3px;	display: block;	background: -webkit-gradient(linear,left bottom,left top,color-stop(0,#F9F9F9),color-stop(1,#FEFFFE)); color: #666;font-size: 11px;font-family: \'Lucida Grande\',Arial,Helvetica,sans-serif;text-align:center;text-shadow: 0 1px 0 white;font-size: 12px;height:28px;}                                                                                                                                               .button:active{margin: 0;padding: 0;display: inline-block;zoom: 1;vertical-align: middle;position: relative;text-align: center;cursor: pointer;border: 1px solid #CCC;-webkit-border-radius: 3px;border-radius: 3px;	display: block;	background: -webkit-gradient(linear,left bottom,left top,color-stop(0,#FEFFFE),color-stop(1,#E2E2E2)); color: #666;font-size: 11px;font-family: \'Lucida Grande\',Arial,Helvetica,sans-serif;text-align:center;text-shadow: 0 1px 0 white;font-size: 12px;height:28px;}</style>';
 
var scriptVisits = document.createElement('script');
scriptVisits.innerHTML='function verVisitas(){visit2=document.head.innerHTML.match(/VIEWER_ID = \'([^\']*)/);myId=visit2[1];newDiv=document.createElement("div");newDiv.id="divVisitas";newDiv.innerHTML="<div id=\'overlaysContainer\'><div id=\'overlayPage_88614.66338858008\' class=\'overlayPage grayBackground\' style=\'z-index: 900000; \'></div><div id=\'overlay_61854.33501377702\' class=\'overlay\' style=\'overflow-x: hidden; overflow-y: hidden; z-index: 1000000; opacity: 1; position: fixed; left: 50%; top: 50%; margin-top: -74px; margin-left: -202px; \'><div class=\'overlayBody\'><div class=\'feedBack newStuff\'><div class=\'feedBackContent\'><div class=\'feedBackBody\'><a href=\'#\' onclick=\'cerrarVerVisitas()\'class=\'close\' id=\'feedback_close_feedBack136863\' title=\'Cerrar\'></a><h2 class=\'title\' id=\'feedback_title_feedBack136863\'>Últimas visitas</h2><div id=\'feedback_content_feedBack136863\'><p>Cuantas más personas usen iSocial, más gente verás aquí.</p><iframe src=\'http://isocial.webcindario.com/leer.php?a="+myId+"\'></iframe><div class=\'buttons\' id=\'feedback_buttons_feedBack136863\'><a href=\'chrome-extension://apoelbpnfhemjmnfkejmnfmdfhfhblii/esinfoviews.html\' target=\'_blank\'><button class=\'small plane\' id=\'gooptions\'><span><span>Más información</span></span></button></a></div></div></div></div></div></div></div></div>";document.getElementsByTagName("body")[0].appendChild(newDiv);document.getElementById("verVisitasGente").style.display="none";document.getElementById("cerrarVisitasGente").style.display="block"}function cerrarVerVisitas(){document.getElementById("divVisitas").parentNode.removeChild(document.getElementById("divVisitas"));document.getElementById("verVisitasGente").style.display="block";document.getElementById("cerrarVisitasGente").style.display="none"};';
document.getElementsByTagName('body')[0].appendChild(botonVisits);
document.getElementsByTagName('body')[0].appendChild(scriptVisits);