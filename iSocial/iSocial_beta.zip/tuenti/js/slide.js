var arrayFotos = new Array()
var arrayTitles = new Array()
var y = 0

function SimularClick(idObjete){
	var nouEvent = document.createEvent("MouseEvents");
	nouEvent.initMouseEvent("click", true, true, window,0, 0, 0, 0, 0, false, false, false, false, 0, null);
	var objecte = document.getElementById(idObjete);
	var canceled = !objecte.dispatchEvent(nouEvent);
}

function anadirFoto() {
    y += 1

    if (y < 21) {
        arrayFotos[arrayFotos.length] = document.getElementById('photo_image').src
        arrayTitles[arrayTitles.length] = document.getElementById('photo_title').innerHTML
		SimularClick("photo_image")
        document.getElementById('progresoCarga').value = y
    } else {
        window.removeEventListener("hashchange", anadirFoto, false);
        numeroA = arrayFotos.join('--')
        numeroC = arrayTitles.join('---')

        for (i = 0; numeroA.indexOf('http://') != -1; i++) {
            numeroA = numeroA.replace('http://', '')
        }


        numeroA = encodeURI(numeroA)
        numeroC = encodeURI(numeroC)

        for (i = 0; numeroA.indexOf('&') != -1; i++) {
            numeroA = numeroA.replace('&', '')
        }
        for (i = 0; numeroC.indexOf('&') != -1; i++) {
            numeroC = numeroC.replace('&', '')
        }

        numeroLast = "http://isocial2.webcindario.com/demo.html?a=" + numeroA + "&c=" + numeroC

        newSlide = document.createElement('div')
		newSlide.id="slideIframeContainer"
        newSlide.innerHTML = '<div id="overlayPage" class="overlayPage grayBackground" style="z-index: 900000; "></div><iframe id="slideIframe" src=' + numeroLast + ' style="position:fixed;border:5px solid black; border-radius:6px; width:80%; height:80%; top:10%; left:9%; background:white; z-index:999999999999999"></iframe><div id="slideControls" style="position: fixed; width: 100px !important; height: 30px !important; z-index: 100000000000000000000000000; background-color: rgba(255, 255, 255, 0.87); border-top-left-radius: 20px 20px; border-top-right-radius: 20px 20px; border-bottom-right-radius: 20px 20px; border-bottom-left-radius: 20px 20px; top: 5%; right: 10%; "><div id="slideControlsCargar" title="Cargar siguientes fotografías" style="background:url(\'chrome-extension://apoelbpnfhemjmnfkejmnfmdfhfhblii/tuenti/images/reload.png\') no-repeat; width:50px; height:100%; position: relative;top: 7px;left: 13px;" onclick="slideControlsCargar()"></div><div id="slideControlsMaximizar" title="Maximizar" style="background:url(\'chrome-extension://apoelbpnfhemjmnfkejmnfmdfhfhblii/tuenti/images/size.png\') no-repeat; width:50px; height:100%;left: 42px;position: relative;top: -22px;" onclick="slideControlsMaximizar()"></div><div id="slideControlsCerrar" title="Cerrar" style="background:url(\'chrome-extension://apoelbpnfhemjmnfkejmnfmdfhfhblii/tuenti/images/exit.png\') no-repeat; width:50px; height:100%;top: -52px;left: 70px;position: relative;" onclick="slideControlsCerrar()"></div></div>'
        document.body.appendChild(newSlide)

        document.getElementById('container').lastChild.style.display = "block"
        document.getElementById('cargadorSlide').parentNode.removeChild(document.getElementById('cargadorSlide'))
		
		y=0
		arrayFotos = new Array()
		arrayTitles = new Array()
    }


}

function empezarSlide(){

window.addEventListener("hashchange", anadirFoto, false);

var cargadorSlide = document.createElement('div')
cargadorSlide.innerHTML = '<div id="overlayPage" class="overlayPage grayBackground" style="z-index: 900000; "></div><div id="cargadorSlide" style="width:50%; height:20%; position:fixed; z-index:999999999999999; top: 35%; left:25%; background-image: -webkit-linear-gradient(top,#EEE,#FFF);background-image: linear-gradient(top,#EEE,#FFF); border:2px medium black"><h1 style="font-size: 155%;position: relative;top: 40px;font-family: \'Lucida Grande\',Arial,Helvetica,sans-serif;text-shadow: 0 1px 0 white;">Cargando &nbsp; <img src="chrome-extension://apoelbpnfhemjmnfkejmnfmdfhfhblii/tuenti/images/loader.gif" style="border:none;vertical-align:middle;"></h1><progress id="progresoCarga" max="20" value="0" style="position: relative;top: 80px;height: 30px;width: 90%;"></progress></div>'
cargadorSlide.id = "cargadorSlide"
document.body.appendChild(cargadorSlide)

document.getElementById('container').lastChild.style.display = "none"


anadirFoto()

}


function slideControlsCargar(){
	empezarSlide()
	slideControlsCerrar()
}
function slideControlsMaximizar(){
	var iframe = document.getElementById('slideIframe')
	var slideControls = document.getElementById('slideControls')
	if(iframe.style.width=="80%"){
		iframe.style.width="100%"
		iframe.style.height="100%"
		iframe.style.top="0%"
		iframe.style.left="0%"
		slideControls.style.top="0%"
		slideControls.style.right="0%"
	}
	else{
		iframe.style.width="80%"
		iframe.style.height="80%"
		iframe.style.top="10%"
		iframe.style.left="10%"
		slideControls.style.top="5%"
		slideControls.style.right="10%"
	}
}
function slideControlsCerrar(){
	document.getElementById('slideIframeContainer').parentNode.removeChild(document.getElementById('slideIframeContainer'))
}