var sesionConect = new Array()

if(localStorage["gruposChat"]==undefined){localStorage["gruposChat"]=""}
if(localStorage["gruposOcultos"]==undefined){localStorage["gruposOcultos"]=""}


function organizarChat(){
	document.getElementById('chat_roster_settings').removeEventListener('click',persone,false)
	document.getElementById('chat_roster_settings').addEventListener('click',persone,false)

if(localStorage["notificacionesChat"]=="true"){

sesionConect2 = document.getElementsByClassName('friend')
sesionConect3 = new Array()
sesionConect4 = new Array()
sesionAuxiliar = 0
sesionNumber = 0

for(i=0;i<sesionConect2.length;i++){
	sesionConect3[i] = sesionConect2[i].id.split('_')[3]
}
for(i=0;i<sesionConect3.length;i++){
	for(k=0;k<sesionConect.length;k++){
		if(sesionConect3[i]==sesionConect[k]){
			sesionAuxiliar = 1	
		}
	}
	if(sesionAuxiliar==0){sesionConect4[sesionNumber]=sesionConect3[i];sesionNumber++}
	else{sesionAuxiliar=0}
}
sesionConect = sesionConect3
if(sesionConect4.length=1&&sesionConect4[0]!=undefined){
var nombreConectado = document.getElementById('roster_item_link_'+sesionConect4[0]).firstChild.textContent
popup = window.webkitNotifications.createNotification("chrome-extension://apoelbpnfhemjmnfkejmnfmdfhfhblii/tuenti/images/notificacioneschat+.png", nombreConectado," se ha conectado.")

popup.show()
setTimeout("popup.cancel()",3000)	
}

}

grupos = localStorage["gruposChat"].split('//')
for(k=0;k<grupos.length;k++){grupos[k]=grupos[k].split(',,')}

var listaChat = document.getElementById('chat_roster_list') 

var estilosChat=document.createElement('style')
estilosChat.type="text/css"
estilosChat.innerHTML='.grupoTitleOn,.grupoTitleOff{font-size:110%;font-weight:bold} .grupoTitleOn:before{content: " ▼ "} .grupoTitleOff:before{content: "  ► "}'
document.getElementsByTagName('head')[0].appendChild(estilosChat)

for(f=0;f<grupos.length;f++){
var title = document.createElement('div')
title.innerHTML='<div class="grupoTitleOn" id="'+grupos[f][0]+'" onclick="ocultarGrupos(this.id) ">'+grupos[f][0]+'</div>'
listaChat.appendChild(title)
for(k=1;k<grupos[f].length;k+=3){
if(document.getElementById('roster_item_item_'+grupos[f][k])){
var amigoChat = document.getElementById('roster_item_item_'+grupos[f][k])
amigoChat.childNodes[1].firstChild.textContent=grupos[f][k+2]
amigoChat.className+=" "+grupos[f][0]
listaChat.appendChild(amigoChat)

}
}
}

var ocultos = localStorage["gruposOcultos"].split(',,')
for(y=1;y<ocultos.length;y++){
   	ocultarGrupos(ocultos[y])
}
}



function ocultarGrupos(parametro){

var title=document.getElementById(parametro)

if(title.className=="grupoTitleOn"){

title.className="grupoTitleOff"
var array=document.getElementsByClassName(parametro)
for(i=0;i<array.length;i++){array[i].style.display="none"}

var actual = localStorage["gruposOcultos"]
if(actual.indexOf(parametro)==-1){actual+=",,"+parametro}
localStorage["gruposOcultos"] = actual

}

else{

title.className="grupoTitleOn"
var array=document.getElementsByClassName(parametro)
for(i=0;i<array.length;i++){array[i].style.display="block"}

var actual = localStorage["gruposOcultos"]
if(actual.indexOf(parametro)!=-1){actual=actual.replace(",,"+parametro,"")}
localStorage["gruposOcultos"] = actual

}
}


function saberSiEstaPuesto(){
var saberEsta1 = document.getElementsByClassName('grupoTitleOn')
var saberEsta2 = document.getElementsByClassName('grupoTitleOff')
if(saberEsta1.length==0&&saberEsta2.length==0){
	if(localStorage["gruposOcultos"]!=""||localStorage["gruposChat"]!=undefined){
		if(document.getElementsByClassName('friend').length!=0){
			organizarChat()
		}
	}
}
}

setInterval("saberSiEstaPuesto()",40)







var esto;
var overAs = false
var overWhat;


function empezar(e ){
   e.dataTransfer.effectAllowed = 'move';
   e.dataTransfer.setData('text/html', this.innerHTML+",,"+this.lang+",,"+this.title);
   esto=this
}
	
function over(e ) {
  // Dejamos mover
  e.dataTransfer.dropEffect = 'move';
  // Dejamos soltar
  return false;
}

function overPerson(){
if(esto!=this){
  overAs = true
  overWhat=this
}
}

function outPerson(){
  overAs = false	
  this.lastChild.style.display="none"
  this.childNodes[1].style.display="none"
}

function onPerson(){
  this.lastChild.style.display="block"
  this.childNodes[1].style.display="block"
}

function soltar (e ) {
	  var data = e.dataTransfer.getData('text/html')
	  data=data.split(',,')
	  imagen = document.createElement('div');
      imagen.className="personGroupChat"
	  imagen.innerHTML=data[0]
	  imagen.lang=data[1]
	  imagen.title=data[2]
	  imagen.draggable=true
	  imagen.ondragstart = empezar;
	  imagen.onmouseout = outPerson;
	  imagen.onmouseover = onPerson;
	  imagen.lastChild.style.display="none"
	  this.removeChild(this.lastChild)
	  if(overAs==true){
		  overWhat.parentNode.insertBefore(imagen,overWhat) 
	  }
	  else{
	      this.appendChild(imagen);
	  }
	  espaciado=document.createElement('div')
	  espaciado.className="espaciado"
	  this.appendChild(espaciado)
	  esto.parentNode.removeChild(esto)
	  overAs = false
	  
	  

	  calcularAnchuraGestor()
	  
}

function calcularAnchuraGestor(){
	var alturaGestor = document.getElementById('parteMedio_Medio').offsetHeight
	var anchoColumna = document.getElementById('parteMedio_Medio').style.WebkitColumnWidth
	if(alturaGestor>300&&anchoColumna=="250px"){var anchoColumna = document.getElementById('parteMedio_Medio').style.WebkitColumnWidth="200px"}
	if(alturaGestor>300&&anchoColumna=="400px"){var anchoColumna = document.getElementById('parteMedio_Medio').style.WebkitColumnWidth="250px"}
	if(alturaGestor>300&&anchoColumna==""){var anchoColumna = document.getElementById('parteMedio_Medio').style.WebkitColumnWidth="400px"}	
}
	
	
var apodoFinal;
	function apodo(a1,a2){
apodoFinal = prompt("Elige un apodo para "+a2,a1)
}

function quitarPersona(aQuitar){
document.getElementById('contentSinGrupo').appendChild(aQuitar)
}

function agregarGrupo(){
var nuevoGrupo = document.createElement('div')
nuevoGrupo.className="groupChat"
nuevoGrupo.innerHTML='<div class="titleGroupChat" contenteditable="true">Cambiar nombre:</div><div class="contentGroupChat"><div class="espaciado"></div></div>'
document.getElementById('parteMedio_Medio').appendChild(nuevoGrupo)
var grupos = document.getElementsByClassName('groupChat')
grupos[grupos.length-1].ondrop = soltar;
grupos[grupos.length-1].ondragover = over;
}

function cancelarBorrando(){
	document.getElementById('borrandoGrupo').parentNode.removeChild(document.getElementById('borrandoGrupo'))
}

function groupdelete(i){
	cancelarBorrando()
	document.getElementsByClassName("groupChat")[i].parentNode.removeChild(document.getElementsByClassName("groupChat")[i])	
}

function crearBorrado(){
	var long = document.getElementsByClassName("titleGroupChat")
	var long2 = new Array()
	for(i=0;i<long.length;i++){
		long2[i]=long[i].innerHTML	
	}
	var borrador = document.createElement('div')
	borrador.id="borrandoGrupo"
	var inner='<div style="font-size: 140%; padding-bottom:20px"><b>Elige el grupo que deseas borrar:</b></div>'
	for(i=0;i<long2.length;i++){
		inner+='<div class="grupoBorrar" onclick="groupdelete('+i+')">'+long2[i]+'</div>'
	}
	inner+='<div id="cancelarBorrando" onclick="cancelarBorrando()">Cancelar</div>'
	borrador.innerHTML=inner
	document.body.appendChild(borrador)
}

function cancelarChatCambio(){
document.getElementById('gestorChat').parentNode.removeChild(document.getElementById('gestorChat'))
}

function guardarGrupos(){
	localStorage["gruposOcultos"]=""
var localChat = ""
var numeroHijos = 0
var titulosChat = document.getElementsByClassName('titleGroupChat')
for(i=0;i<titulosChat.length;i++){
        if(titulosChat[i].nextSibling.className=="contentGroupChat"){
	        numeroHijos = titulosChat[i].nextSibling.childNodes.length
        }
        else{
                numeroHijos = titulosChat[i].parentNode.childNodes.length-1
        }
	localChat += titulosChat[i].innerHTML
	for(k=0;k<numeroHijos-1;k++){
                localChat += ",,"
                if(titulosChat[i].nextSibling.className=="contentGroupChat"){
		    		 localChat += titulosChat[i].nextSibling.childNodes[k].lang
		    		 localChat += ",,"
		    		 localChat += titulosChat[i].nextSibling.childNodes[k].title
		    		 localChat += ",,"
		    		 localChat += titulosChat[i].nextSibling.childNodes[k].firstChild.textContent
                }
                else{ 
		    		 localChat += titulosChat[i].parentNode.childNodes[k+1].lang
		    		 localChat += ",,"
		    		 localChat += titulosChat[i].parentNode.childNodes[k+1].title
		    		 localChat += ",,"
		    		 localChat += titulosChat[i].parentNode.childNodes[k+1].firstChild.textContent
                }
	}
        if(i!=titulosChat.length-1){
	        localChat += "//"
        }
        else{
                localStorage["gruposChat"]=localChat
        }
}
cancelarGrupos()
}
	
function cancelarGrupos(){
    document.getElementById('gestorChat').parentNode.removeChild(document.getElementById('gestorChat'))
}

function ordenarAZ(){
var viejoArray = document.getElementsByClassName('personGroupChat')
nuevoArray = new Array()
for(i=0;i<viejoArray.length;i++){
nuevoArray[i]=viejoArray[i].title
}
nuevoArray.sort()
for(i=0;i<nuevoArray.length;i++){
	var jur = document.querySelector('.personGroupChat[title="'+nuevoArray[i]+'"]')
	jur.parentNode.insertBefore(jur,jur.parentNode.lastChild)
}
jur.parentNode
jur.parentNode.insertBefore(jur,jur.parentNode.lastChild)
}

//--------------------------------------------------------------------------------------------------------------------------

function persone2(){
var chatOpcion = document.querySelector('#chat_settings_overlay ul')
var newOpcion = document.createElement('li')
newOpcion.innerHTML='<a href="#" title class onclick="saberName()">Gestor chat</a>'
chatOpcion.appendChild(newOpcion)
}
function persone(){
setTimeout("persone2()",40)
}


//-------------------------------------------------------------------------------------------------------

function saberName() {
	var grupos = localStorage["gruposChat"].split('//')
	for(i=0;i<grupos.length;i++){grupos[i]=grupos[i].split(',,')}
    
	var gestor = document.createElement('div')
	gestor.id="gestorChat"
	gestor.innerHTML=""
	var futuroHTML = ""
	
	futuroHTML+='<div id="overlaysContainerDiv"><div class="overlayPageBackground"></div><div id="confirmDialog4" class="overlay" style="overflow-x: hidden; overflow-y: hidden; z-index: 1000000; opacity: 1;"><div class="overlayBody"><div class="feedBack information" style="width: 900px!important;"><div class="feedBackContent"><div class="feedBackBody"><a href="#" onclick="cancelarGrupos()" class="close" id="dialog_close_confirmDialog4" title="Cerrar" onclick=""></a><h2 id="dialog_title_confirmDialog4">Configurar chat</h2><div id="parteMedio"><div id="parteMedio_Arriba"><div id="parteMedio_Arriba_Izquierda"><input type="checkbox" name="activarNotificaciones" id="activarNotificaciones" onclick="activaNotificaciones(this.checked)"><label for="activarNotificaciones" style="font-size: 11px;	font-weight: bold;	font-family: Arial;"> Avisar cuando alguien <br>se conecte al chat</label><button class="button" id="grouporder" onclick="ordenarAZ()">Ordenar A-Z</button></div><div id="parteMedio_Arriba_Derecha"><button id="groupadd" class="button">Añadir grupo</button><button id="groupdelete" class="button">Borrar grupo</button><button id="groupsave" class="button">Guardar</button></div></div><div id="parteMedio_Medio">'
	if (grupos[0].length==1){}
	else{
	for(i=0;i<grupos.length;i++){
		var titulo = grupos[i][0]
		futuroHTML+='<div class="groupChat"><div class="titleGroupChat" contenteditable="true">'+titulo+'</div><div class="contentGroupChat">'	
		for(k=1;k<grupos[i].length;k+=3){
			futuroHTML+='<div class="personGroupChat" lang="'+grupos[i][k]+'" title="'+grupos[i][k+1]+'" draggable="true">'+grupos[i][k+2]+'<div class="quitarPersona" onclick="quitarPersona(this.parentNode)" style="display: none;" title="Eliminar del grupo"></div><div class="apodar" title="Nuevo apodo" style="display: none;" onclick="javascript:actualName=prompt(\'Elige un apodo para '+grupos[i][k+1]+':\');if(actualName!=null){this.parentNode.firstChild.textContent=actualName}"></div></div>'
		}		
		futuroHTML+='<div class="espaciado"></div></div></div>'
	}
	}
	futuroHTML+='</div></div>'
	
	
	
	
	var listaConect = document.getElementsByClassName('friend')
    var listaConectados = new Array()
	var listaConectados2 = new Array()
	var listaConectadosFinal = new Array()
	var h =0
	
    for(i=0;i<listaConect.length;i++){
        listaConectados[i] = listaConect[i].id.split('_')[3]
    }
	
	for(i=0;i<grupos.length;i++){
		for(k=1;k<grupos[i].length;k+=3){
		    listaConectados2[h]=grupos[i][k]	
			h++
		}
	}
	
	var h = 0
	var f = 0
	
	for(i=0;i<listaConectados.length;i++){
        for(k=0;k<listaConectados2.length;k++){
            if(listaConectados[i]==listaConectados2[k]){h=1}
        }
        if(h!=0){h=0}
        else{listaConectadosFinal[f]=listaConectados[i];f++}
	}
	
	futuroHTML+='<div id="parteAbajo"><div id="parteAbajo_Izquierda"><div id="titleSinGrupo">Gente sin grupo:</div><div id="contentSinGrupo">'
	
	for(i=0;i<listaConectadosFinal.length;i++){
    var personaActual=document.getElementById('roster_item_link_'+listaConectadosFinal[i]).firstChild.textContent.replace(/^\s*|\s*$/g,"");
    futuroHTML+='<div class="personGroupChat" lang="'+listaConectadosFinal[i]+'" title="'+personaActual+'" draggable="true">'+personaActual+'<div class="quitarPersona" onclick="quitarPersona(this.parentNode)" style="display: none; "></div><div class="apodar" style="display: none; " onclick="javascript:actualName=prompt(\'Elige un apodo para '+personaActual+':\');if(actualName!=null){this.parentNode.firstChild.textContent=actualName}"></div></div>'
    }
	futuroHTML+='</div></div><div id="parteAbajo_Derecha"><div id="cancelar">Cancelar</div></div></div></div></div></div></div></div>'
	
	gestor.innerHTML=futuroHTML
	document.body.appendChild(gestor)
	
	var estilos = document.createElement('style')
	estilos.type="text/css"
	estilos.innerHTML=".groupChat{border:1px solid black;border-radius:3px;box-shadow:0 0 1px blue;margin:5px;padding:5px 5px 0;}                                                                                                                                                                                                                                                                                                  .titleGroupChat{font-size: 12px;	font-weight: bold;	font-family: Arial;}                                                                                                                                                                                                                                                                                                  .personGroupChat{text-align:center;width: 165px !important;height: 10px !important;;top:-20px;margin-bottom:4px;font-size: 11px;	font-weight: bold;	font-family: Arial; padding: 8px;text-shadow: #66A243 -0 -1px 0;color: white;font-size: 11px;line-height: 13px;text-align: left;border: 1px solid #85B03B;border-top: 1px solid #BAD89A;background-color: #A3CA79;background-image: -webkit-gradient(linear,left top,left bottom,from(#A3CA79),to(#85B03B));background-image: -webkit-linear-gradient(top,#A3CA79,#85B03B);background-image: linear-gradient(top,#A3CA79,#85B03B);}                                                                                                                                                                                                                                                                                                  .personGroupChat:hover{background-color: #b2dc85;background-image: -webkit-gradient(linear,left top,left bottom,from(#b2dc85),to(#85B03B));background-image: -webkit-linear-gradient(top,#b2dc85,#85B03B);background-image: linear-gradient(top,#b2dc85,#85B03B);}                                                                                                                                                                                                                                                                                                  .personGroupChat:active{background-color: #99bd72;background-image: -webkit-gradient(linear,left top,left bottom,from(#99bd72),to(#85B03B));background-image: -webkit-linear-gradient(top,#99bd72,#85B03B);background-image: linear-gradient(top,#99bd72,#85B03B);}                                                                                                                                                                                                                                                                                                  .contentGroupChat{min-height:15px;}                                                                                                                                                                                                                                                                                                  #gestorChat{position:absolute;top:15%;left:15%;z-index:2000;text-align:left;}                                                                                                                                                                                                                                                                                                  #parteArriba{border-bottom:1px solid black;height:50px;}#apodosSoloChat{position:relative;top:2px;}                                                                                                                                                                                                                                                                                                  #sonidoInicio{position:relative;top:-30px;left:-120px;text-align:center;width:250px;margin-left:300px;}                                                                                                                                                                                                                                                                                                  #apodoDe{position:relative;top:-55px;width:400px;margin-left:440px;text-align:center;}                                                                                                                                                                                                                                                                                                  #parteMedio_Arriba{padding-top:15px;font-size:110%;height:60px;}#labelApodos{position:relative;left:4px;}#parteMedio_Arriba_Derecha{position:relative;top:-50px;text-align:right;left:600px;}                                                                                                                                                                                                                                                                                                  #groupadd{width:93px;text-align:center;position:relative;left:-70px;} #groupdelete{width:93px;text-align:center;position:relative;left:30px;top:-28px;}                       #groupsave{width:70px;text-align:center;position:relative;left:130px;top: -56px;}                               #grouporder{width: 100px;text-align:center;position: relative;top: -25px;left: 160px;}                                                                                                                                                                                                                                                                                                  #parteMedio_Medio{border-bottom:1px solid black;padding-bottom:0;}#cancelar{font-size:140%;color:blue;position:relative;left:610px;top:20px;}                                                                                                                                                                                                                                                                                                  .espaciado{height:15px;}                                                                                                                                                                                                                                                                                                  #titleSinGrupo{top:5px;position:relative;font-size:130%;}                                                                                                                                                                                                                                                                                                  #contentSinGrupo{width:600px;position:relative;top:10px;}                                                                                                                                                                                                                                                                                                  .button{margin: 0;padding: 0;display: inline-block;zoom: 1;vertical-align: middle;position: relative;text-align: center;cursor: pointer;border: 1px solid #CCC;-webkit-border-radius: 3px;border-radius: 3px;	display: block;	background: -webkit-gradient(linear,left bottom,left top,color-stop(0,#E2E2E2),color-stop(1,#FEFFFE)); color: #666;font-size: 11px;font-family: 'Lucida Grande',Arial,Helvetica,sans-serif;text-align:center;text-shadow: 0 1px 0 white;font-size: 12px;height:28px;}                                                                                                                                                   .button:hover{margin: 0;padding: 0;display: inline-block;zoom: 1;vertical-align: middle;position: relative;text-align: center;cursor: pointer;border: 1px solid #CCC;-webkit-border-radius: 3px;border-radius: 3px;	display: block;	background: -webkit-gradient(linear,left bottom,left top,color-stop(0,#F9F9F9),color-stop(1,#FEFFFE)); color: #666;font-size: 11px;font-family: 'Lucida Grande',Arial,Helvetica,sans-serif;text-align:center;text-shadow: 0 1px 0 white;font-size: 12px;height:28px;}                                                                                                                                               .button:active{margin: 0;padding: 0;display: inline-block;zoom: 1;vertical-align: middle;position: relative;text-align: center;cursor: pointer;border: 1px solid #CCC;-webkit-border-radius: 3px;border-radius: 3px;	display: block;	background: -webkit-gradient(linear,left bottom,left top,color-stop(0,#FEFFFE),color-stop(1,#E2E2E2)); color: #666;font-size: 11px;font-family: 'Lucida Grande',Arial,Helvetica,sans-serif;text-align:center;text-shadow: 0 1px 0 white;font-size: 12px;height:28px;}                                                                                                                                                                                                                                                                                              .apodar{top:-28px;position:relative;right:10px;background-image: url(chrome-extension://apoelbpnfhemjmnfkejmnfmdfhfhblii/tuenti/images/gestorchatadd.png);width:15px;height:15px;left:150px;}                                                                                                                                                                                                                                                                                           #borrandoGrupo{width:300px;position:absolute;background:white;z-index:9999;left:35%;top:30%;border:3px solid black;border-radius:40px;padding:20px;}                                                                                                                                                                                                                                                                                           .grupoBorrar{width:270px;text-align:center;background:lightBlue;border-radius:15px;font-size:110%;border:1px solid black;margin:5px;padding:5px;}                                                                                                                                                                                                                                                                                           #cancelarBorrando{color:blue;font-size:150%;text-align:right;margin-right:20px;margin-top:20px;}                                                                                                                                                                                                                                                                                           #parteMedio_Arriba_Izquierda{margin-left:20px}                                                                                                                                                                                                                                                                                           .quitarPersona {background-image: url(chrome-extension://apoelbpnfhemjmnfkejmnfmdfhfhblii/tuenti/images/gestorchatdelete.png);width: 15px;top: -13px;position: relative;left: 133px;height: 15px;}                                                                                                                                                                                                                                                                                                                                                                                                                                             "
	document.body.appendChild(estilos)
	
	//Unimos cada objeto con su evento......
	
	document.getElementById('groupadd').onclick= agregarGrupo
	document.getElementById('groupdelete').onclick= crearBorrado
	document.getElementById('groupsave').onclick= guardarGrupos
	document.getElementById('cancelar').onclick= cancelarGrupos
	document.getElementById('cancelar').onclick = cancelarChatCambio
	var contentGroupChat = document.getElementsByClassName('contentGroupChat')
	var personGroupChat = document.getElementsByClassName('personGroupChat')
	var groupChat = document.getElementsByClassName('groupChat')
	
	for(i=0;i<contentGroupChat.length;i++){
	document.getElementsByClassName('contentGroupChat')[i].ondragover = over;
	document.getElementsByClassName('contentGroupChat')[i].ondrop = soltar;
	}
	
	for(i=0;i<personGroupChat.length;i++){
	document.getElementsByClassName('personGroupChat')[i].ondragstart = empezar;
	document.getElementsByClassName('personGroupChat')[i].ondragover = overPerson;
	document.getElementsByClassName('personGroupChat')[i].onmouseout = outPerson;
	document.getElementsByClassName('personGroupChat')[i].onmouseover = onPerson;
	}
	
	document.getElementById('groupadd').onclick= agregarGrupo

 calcularAnchuraGestor()
 calcularAnchuraGestor()
 calcularAnchuraGestor()
}


function activaNotificaciones(check){
if(check==true){
localStorage["notificacionesChat"]="true"
window.webkitNotifications.requestPermission();
}
else{
localStorage["notificacionesChat"]="false"
}
}