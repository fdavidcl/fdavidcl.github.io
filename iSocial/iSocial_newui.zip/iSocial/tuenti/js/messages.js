//Funciones de cerrado

function closemesagge(){
	document.getElementById('mainmessage').parentNode.removeChild(document.getElementById('mainmessage'))
}

function closemesaggecentral(){
	document.getElementById('centralmessage').parentNode.removeChild(document.getElementById('centralmessage'))
}

function closemesaggeradio(){
	document.getElementById('radiomessage').parentNode.removeChild(document.getElementById('radiomessage'))
}

function closemesaggetv(){
	document.getElementById('tvmessage').parentNode.removeChild(document.getElementById('tvmessage'))
}


//Funciones de minimizado

function minimizarradio(){
	var tabla = document.getElementById('tabla')
	var minimizar = document.getElementById('minimizar_radio')
	var cerrar = document.getElementById('close_radio')
	if(tabla.style.display=="none"){tabla.style.display="block";cerrar.style.display="block";minimizar.style.bottom="245px !important";minimizar.style.right="25px !important"}
	else{tabla.style.display="none";cerrar.style.display="none";minimizar.style.bottom="25px !important";minimizar.style.right="-3px !important";}
}

//Radio

//Cambiar canal de radio

function cambiarCanal(laId){

	event.returnValue = false;

	var objeto = document.getElementById(laId)

	var src = objeto.href

	document.getElementById('iframe').src=src

}

//Div de radio

function openradioclosemesagge(){
	document.getElementById('centralmessage').parentNode.removeChild(document.getElementById('centralmessage'))
	
	var radiomessage = document.createElement('div')
	radiomessage.innerHTML = '<div id="light_box" class="overlay" style="opacity: 1; z-index: 999; position: fixed; bottom: -25px; right: -7px; "><div class="overlayBody lightbox"><div><div class="action"><a href="#" style="left:510px" id="close_radio" class="close" title="Cerrar" onclick="closemesaggeradio()"></a><a id="minimizar_radio" class="maximizado" href="#" onclick="minimizarradio()"></a></div> <h2>Radio</h2><style type="text/css">.maximizado {width: 30px !important; height: 30px !important; background-image: url(chrome-extension://apoelbpnfhemjmnfkejmnfmdfhfhblii/tuenti/images/maximizado.png); position: fixed; right: 30px; bottom: 243px;}.maximizado:hover {width: 30px !important; height: 30px !important; background-image: url(chrome-extension://apoelbpnfhemjmnfkejmnfmdfhfhblii/tuenti/images/maximizado_hover.png); position: fixed; right: 30px; bottom: 243px;}#tabla a {color: #36679F;text-decoration: none;}#tabla table,#tabla td,#tabla th {vertical-align: middle;}#tabla {border-collapse: collapse;border-spacing: 0;}caption,#tabla th,#tabla td {text-align: left;font-weight: normal;}#tabla td {width: 166px;}#tabla td a span {width: 95px;line-height: 14px;background: url(chrome-extension://apoelbpnfhemjmnfkejmnfmdfhfhblii/tuenti/images/icoradio.png) no-repeat 0 0;padding: 8px 0 0 45px;display: block;height: 25px;text-decoration: none;}#tabla tr {border-bottom: 1px solid #ECECEC;height:55px !important;}#tabla td:hover{background-image: linear-gradient(bottom, rgb(240,240,240) 5%, rgb(255,255,255) 90%);background-image: -o-linear-gradient(bottom, rgb(240,240,240) 5%, rgb(255,255,255) 90%);background-image: -moz-linear-gradient(bottom, rgb(240,240,240) 5%, rgb(255,255,255) 90%);background-image: -webkit-linear-gradient(bottom, rgb(240,240,240) 5%, rgb(255,255,255) 90%);background-image: -ms-linear-gradient(bottom, rgb(240,240,240) 5%, rgb(255,255,255) 90%);background-image: -webkit-gradient(	linear,	left bottom,	left top,	color-stop(0.05, rgb(240,240,240)),	color-stop(0.9, rgb(255,255,255)))} #tabla td a span.hitfm {background-position: -5px -98px;} #tabla td a span.europafm {background-position: -5px -148px;}#tabla td a span.kissfm {background-position: -5px -181px;} #tabla td a span.los40 {background-position: -3px -220px;} #tabla td a span.cadena100 {background-position: -3px -275px;} #tabla td a span.cadenadial {background-position: -3px -330px;} #tabla td a span.ondacero {background-position: -3px -384px;} #tabla td a span.cadenaser {background-position: -3px -445px;} #tabla td a span.m80 {background-position: -3px -493px;} #tabla td a span.rne {background-position: -3px -539px;} #tabla td a span.radioclasica {background-position: -3px -585px;} #tabla td a span.cope {background-position: -3px -633px;}</style></head><body><table id="tabla"><tr><td><a id="hitfm" href="http://www.hitfm.es/" onclick="cambiarCanal(this.id)" title="Hit FM"><span class="hitfm">Hit FM</span></a></td><td><a id="europafm" href="http://www.europafm.com/directo/" onclick="cambiarCanal(this.id)" title="Europa FM"><span class="europafm">Europa FM</span></a></td><td><a id="kissfm" href="http://www.kissfm.es/player/kissplayer/index.php" onclick="cambiarCanal(this.id)" title="Kiss FM"><span class="kissfm">Kiss FM</span></a></td></tr><tr><td><a id="los40" href="http://www.los40.com/player/" onclick="cambiarCanal(this.id)" title="Los 40"><span class="los40">Los 40</span></a></td><td><a id="cadena100" href="http://player.cadena100.es/" onclick="cambiarCanal(this.id)" title="Cadena 100"><span class="cadena100">Cadena 100</span></a></td><td><a id="cadenadial" href="http://www.cadenadial.com/player/" onclick="cambiarCanal(this.id)" title="Cadena 100"><span class="cadenadial">Cadena Dial</span></a></td></tr><tr><td><a id="ondacero" href="http://www.ondacero.es/directo/" onclick="cambiarCanal(this.id)" title="Onda cero"><span class="ondacero">Onda Cero</span></a></td><td><a id="cadenaser" href="http://www.cadenaser.com/player_radio.html" onclick="cambiarCanal(this.id)" title="Cadena ser"><span class="cadenaser">Cadena ser</span></a></td><td><a id="m80" href="http://www.m80radio.com/multimedia/radios.html" onclick="cambiarCanal(this.id)" title="M80"><span class="m80">M80</span></a></td></tr><tr><td><a id="rne" href="http://www.rtve.es/alacarta/live_radio_PopUp.shtml?id=3348&v=0.75&vp=&lang=es" onclick="cambiarCanal(this.id)" title="RNE"><span class="rne">RNE</span></a></td><td><a id="radioclasica" href="http://www.rtve.es/alacarta/live_radio_PopUp.shtml?id=3343&v=0.75&vp=&lang=es" onclick="cambiarCanal(this.id)" title="Radio Clásica"><span class="radioclasica">Radio Clásica</span></a></td><td><a id="cope" href="http://www.cope.es/player.php5" onclick="cambiarCanal(this.id)" title="Cope"><span class="cope">Cope</span></a></td></tr></table><iframe id="iframe" src="" width="0px" height="0px" style="width:0px; height:0px; display:none"></iframe></body></div></div></div>'
	radiomessage.id = "radiomessage"
	document.body.appendChild(radiomessage)
}

//Televisión

//Canal La 1
function closemesaggetvloadchannelLA1(){
	document.getElementById('tvmessage').parentNode.removeChild(document.getElementById('tvmessage'))
	
	var tvmessageLA1 = document.createElement('div')
	tvmessageLA1.innerHTML = '<div id="light_box" class="overlay" style="opacity: 1; z-index: 999; position: fixed; bottom: -25px; right: -7px; "><div class="overlayBody lightbox"><div><div class="action"><a href="#" style="margin-right: 710px;" id="close_radio" class="close" title="Cerrar" onclick="closemesaggetv()"></a><a id="minimizar_radio" class="maximizado" href="#" onclick="minimizarradio()"></a></div> <h2>La 1</h2><style type="text/css">.maximizado {display:none;width: 30px !important; height: 30px !important; background-image: url(chrome-extension://apoelbpnfhemjmnfkejmnfmdfhfhblii/tuenti/images/maximizado.png); position: fixed; right: 30px; bottom: 243px;}.maximizado:hover {width: 30px !important; height: 30px !important; background-image: url(chrome-extension://apoelbpnfhemjmnfkejmnfmdfhfhblii/tuenti/images/maximizado_hover.png); position: fixed; right: 30px; bottom: 243px;}</style></head><body><div id="container" style="overflow:hidden; width: 670px; height:409px; position:relative; left:40px; bottom:0px"><iframe id="iframe" scrolling="no" src="http://www.rtve.es/noticias/directo-la-1/" style="width: 613px;height: 900px; margin-left: -5px;margin-top: -450px;"></iframe></div></body></div></div></div>'
	tvmessageLA1.id = "tvmessage"
	document.body.appendChild(tvmessageLA1)
}


//Canal TDP
function closemesaggetvloadchannelTDP(){
	document.getElementById('tvmessage').parentNode.removeChild(document.getElementById('tvmessage'))
	
	var tvmessageTDP = document.createElement('div')
	tvmessageTDP.innerHTML = '<div id="light_box" class="overlay" style="opacity: 1; z-index: 999; position: fixed; bottom: -25px; right: -7px; "><div class="overlayBody lightbox"><div><div class="action"><a href="#" style="margin-right: 710px;" id="close_radio" class="close" title="Cerrar" onclick="closemesaggetv()"></a><a id="minimizar_radio" class="maximizado" href="#" onclick="minimizarradio()"></a></div> <h2>TDP</h2><style type="text/css">.maximizado {display:none;width: 30px !important; height: 30px !important; background-image: url(chrome-extension://apoelbpnfhemjmnfkejmnfmdfhfhblii/tuenti/images/maximizado.png); position: fixed; right: 30px; bottom: 243px;}.maximizado:hover {width: 30px !important; height: 30px !important; background-image: url(chrome-extension://apoelbpnfhemjmnfkejmnfmdfhfhblii/tuenti/images/maximizado_hover.png); position: fixed; right: 30px; bottom: 243px;}</style></head><body><div id="container" style="overflow:hidden; width: 670px; height:409px; position:relative; left:40px; bottom:0px"><iframe id="iframe" scrolling="no" src="http://www.rtve.es/deportes/directo/teledeporte/" style="width: 560px;height: 810px;margin-left: 25px;margin-top: -430px;"></iframe></div></body></div></div></div>'
	tvmessageTDP.id = "tvmessage"
	document.body.appendChild(tvmessageTDP)
}

//Canal 24H
function closemesaggetvloadchannel24H(){
	document.getElementById('tvmessage').parentNode.removeChild(document.getElementById('tvmessage'))
	
	var tvmessage24H = document.createElement('div')
	tvmessage24H.innerHTML = '<div id="light_box" class="overlay" style="opacity: 1; z-index: 999; position: fixed; bottom: -25px; right: -7px; "><div class="overlayBody lightbox"><div><div class="action"><a href="#" style="margin-right: 710px;" id="close_radio" class="close" title="Cerrar" onclick="closemesaggetv()"></a><a id="minimizar_radio" class="maximizado" href="#" onclick="minimizarradio()"></a></div> <h2>24 Horas</h2><style type="text/css">.maximizado {display:none;width: 30px !important; height: 30px !important; background-image: url(chrome-extension://apoelbpnfhemjmnfkejmnfmdfhfhblii/tuenti/images/maximizado.png); position: fixed; right: 30px; bottom: 243px;}.maximizado:hover {width: 30px !important; height: 30px !important; background-image: url(chrome-extension://apoelbpnfhemjmnfkejmnfmdfhfhblii/tuenti/images/maximizado_hover.png); position: fixed; right: 30px; bottom: 243px;}</style></head><body><div id="container" style="overflow:hidden; width: 670px; height:409px; position:relative; left:40px; bottom:0px"><iframe id="iframe" scrolling="no" src="http://www.rtve.es/noticias/directo/canal-24h/" style="width: 620px;height: 859px;margin-left: 25px;margin-top: -450px;"></iframe></div></body></div></div></div>'
	tvmessage24H.id = "tvmessage"
	document.body.appendChild(tvmessage24H)
}

//Canal Antena3

function closemesaggetvloadchannelAntena3(){
	document.getElementById('tvmessage').parentNode.removeChild(document.getElementById('tvmessage'))
	
	var tvmessageAntena3 = document.createElement('div')
	tvmessageAntena3.innerHTML = '<div id="light_box" class="overlay" style="opacity: 1; z-index: 999; position: fixed; bottom: -25px; right: -7px; "><div class="overlayBody lightbox"><div><div class="action"><a href="#" style="margin-right: 710px;" id="close_radio" class="close" title="Cerrar" onclick="closemesaggetv()"></a><a id="minimizar_radio" class="maximizado" href="#" onclick="minimizarradio()"></a></div><h2>Antena3</h2><style type="text/css">.maximizado {display:none;width: 30px !important; height: 30px !important; background-image: url(chrome-extension://apoelbpnfhemjmnfkejmnfmdfhfhblii/tuenti/images/maximizado.png); position: fixed; right: 35px; bottom: 433px;}.maximizado:hover {width: 30px !important; height: 30px !important; background-image: url(chrome-extension://apoelbpnfhemjmnfkejmnfmdfhfhblii/tuenti/images/maximizado_hover.png); position: fixed; right: 30px; bottom: 243px;}</style></head><body><div id="container" style="overflow:hidden; width: 670px; height:409px; position:relative; left:40px; bottom:0px"><iframe id="iframe" scrolling="no" src="http://www.vertdtgratis.es/cuatro16index22.html" style="width:760px; height:400px; margin-left:-5px;"></iframe></div></body></div></div></div>'
	tvmessageAntena3.id = "tvmessage"
	document.body.appendChild(tvmessageAntena3)
}

//Canal Cuatro

function closemesaggetvloadchannelCuatro(){
	document.getElementById('tvmessage').parentNode.removeChild(document.getElementById('tvmessage'))
	
	var tvmessageCuatro = document.createElement('div')
	tvmessageCuatro.innerHTML = '<div id="light_box" class="overlay" style="opacity: 1; z-index: 999; position: fixed; bottom: -25px; right: -7px; "><div class="overlayBody lightbox"><div><div class="action"><a href="#" style="margin-right: 710px;" id="close_radio" class="close" title="Cerrar" onclick="closemesaggetv()"></a><a id="minimizar_radio" class="maximizado" href="#" onclick="minimizarradio()"></a></div><h2>Cuatro</h2><style type="text/css">.maximizado {display:none;width: 30px !important; height: 30px !important; background-image: url(chrome-extension://apoelbpnfhemjmnfkejmnfmdfhfhblii/tuenti/images/maximizado.png); position: fixed; right: 35px; bottom: 433px;}.maximizado:hover {width: 30px !important; height: 30px !important; background-image: url(chrome-extension://apoelbpnfhemjmnfkejmnfmdfhfhblii/tuenti/images/maximizado_hover.png); position: fixed; right: 30px; bottom: 243px;}</style></head><body><div id="container" style="overflow:hidden; width: 670px; height:409px; position:relative; left:40px; bottom:0px"><iframe id="iframe" scrolling="no" src="http://play.cuatro.com/directo/portada/ver/cuatro-en-directo" style="width: 760px;height: 500px;margin-left: -5px;margin-top: -120px;"></iframe></div></body></div></div></div>'
	tvmessageCuatro.id = "tvmessage"
	document.body.appendChild(tvmessageCuatro)
}


//Canal TeleCinco

function closemesaggetvloadchannelTeleCinco(){
	document.getElementById('tvmessage').parentNode.removeChild(document.getElementById('tvmessage'))
	
	var tvmessageTeleCinco = document.createElement('div')
	tvmessageTeleCinco.innerHTML = '<div id="light_box" class="overlay" style="opacity: 1; z-index: 999; position: fixed; bottom: -25px; right: -7px; "><div class="overlayBody lightbox"><div><div class="action"><a href="#" style="margin-right: 740px;" id="close_radio" class="close" title="Cerrar" onclick="closemesaggetv()"></a><a id="minimizar_radio" class="maximizado" href="#" onclick="minimizarradio()"></a></div><h2>TeleCinco</h2><style type="text/css">.maximizado {display:none;width: 30px !important; height: 30px !important; background-image: url(chrome-extension://apoelbpnfhemjmnfkejmnfmdfhfhblii/tuenti/images/maximizado.png); position: fixed; right: 35px; bottom: 433px;}.maximizado:hover {width: 30px !important; height: 30px !important; background-image: url(chrome-extension://apoelbpnfhemjmnfkejmnfmdfhfhblii/tuenti/images/maximizado_hover.png); position: fixed; right: 30px; bottom: 243px;}</style></head><body><div id="container" style="overflow:hidden; width: 700px; height:409px; position:relative; left:40px; bottom:0px"><iframe id="iframe" scrolling="no" src="http://www.telecinco.es/endirecto/" style="width: 760px;height: 760px;margin-left: -10px;margin-top: -380px;"></iframe></div></body></div></div></div>'
	tvmessageTeleCinco.id = "tvmessage"
	document.body.appendChild(tvmessageTeleCinco)
}


//Div de televisión

function opentvclosemesagge(){
	document.getElementById('centralmessage').parentNode.removeChild(document.getElementById('centralmessage'))
	
	var tvmessage = document.createElement('div')
	tvmessage.innerHTML = '<div id="light_box" class="overlay" style="opacity: 1; z-index: 999; position: fixed; bottom: -25px; right: -7px; "><div class="overlayBody lightbox"><div><div class="action"><a href="#" style="left:510px" id="close_radio" class="close" title="Cerrar" onclick="closemesaggetv()"></a><a id="minimizar_radio" class="maximizado" href="#" onclick="minimizarradio()"></a></div> <h2>Televisión</h2><style type="text/css">.maximizado {display:none;width: 30px !important; height: 30px !important; background-image: url(chrome-extension://apoelbpnfhemjmnfkejmnfmdfhfhblii/tuenti/images/maximizado.png); position: fixed; right: 30px; bottom: 243px;}.maximizado:hover {width: 30px !important; height: 30px !important; background-image: url(chrome-extension://apoelbpnfhemjmnfkejmnfmdfhfhblii/tuenti/images/maximizado_hover.png); position: fixed; right: 30px; bottom: 243px;}#tabla a {color: #36679F;text-decoration: none;}#tabla table,#tabla td,#tabla th {vertical-align: middle;}#tabla {border-collapse: collapse;border-spacing: 0;}caption,#tabla th,#tabla td {text-align: left;font-weight: normal;}#tabla td {width: 166px;}#tabla td a span {width: 95px;line-height: 14px;background: url(chrome-extension://apoelbpnfhemjmnfkejmnfmdfhfhblii/tuenti/images/icotv.png) no-repeat 0 0;padding: 8px 0 0 45px;display: block;height: 25px;text-decoration: none;}#tabla tr {border-bottom: 1px solid #ECECEC;height:55px !important;}#tabla td:hover{background-image: linear-gradient(bottom, rgb(240,240,240) 5%, rgb(255,255,255) 90%);background-image: -o-linear-gradient(bottom, rgb(240,240,240) 5%, rgb(255,255,255) 90%);background-image: -moz-linear-gradient(bottom, rgb(240,240,240) 5%, rgb(255,255,255) 90%);background-image: -webkit-linear-gradient(bottom, rgb(240,240,240) 5%, rgb(255,255,255) 90%);background-image: -ms-linear-gradient(bottom, rgb(240,240,240) 5%, rgb(255,255,255) 90%);background-image: -webkit-gradient(	linear,	left bottom,	left top,	color-stop(0.05, rgb(240,240,240)),	color-stop(0.9, rgb(255,255,255)))} #tabla td a span.hitfm {background-position: -5px -98px;} #tabla td a span.europafm {background-position: -5px -148px;}#tabla td a span.kissfm {background-position: -5px -181px;} #tabla td a span.los40 {background-position: -3px -220px;} #tabla td a span.cadena100 {background-position: -3px -275px;} #tabla td a span.cadenadial {background-position: -3px -330px;} #tabla td a span.ondacero {background-position: -3px -384px;} #tabla td a span.cadenaser {background-position: -3px -445px;} #tabla td a span.m80 {background-position: -3px -493px;} #tabla td a span.rne {background-position: -3px -539px;} #tabla td a span.radioclasica {background-position: -3px -585px;} #tabla td a span.cope {background-position: -3px -633px;}</style></head><body><table id="tabla"><tr><td><a id="la1" href="#" onclick="closemesaggetvloadchannelLA1()" title="La 1"><span class="hitfm">La 1</span></a></td><td><a id="europafm" href="#" onclick="closemesaggetvloadchannelTDP()" title=""><span class="europafm">TDP</span></a></td><td><a id="kissfm" href="#" onclick="closemesaggetvloadchannel24H()" title=""><span class="kissfm">24 Horas</span></a></td></tr><tr><td><a id="los40" href="#" onclick="closemesaggetvloadchannelAntena3()" title="Antena3"><span class="los40">Antena3</span></a></td><td><a id="cadena100" href="#" onclick="closemesaggetvloadchannelCuatro()" title=""><span class="cadena100">Cuatro</span></a></td><td><a id="cadenadial" href="#" onclick="closemesaggetvloadchannelTeleCinco()" title=""><span class="cadenadial">TeleCinco</span></a></td></tr></table><iframe id="iframe" src="" width="0px" height="0px" style="width:0px; height:0px; display:none"></iframe></body></div></div></div>'
	tvmessage.id = "tvmessage"
	document.body.appendChild(tvmessage)
}



//Mensaje acceso opciones

function loadmessageaccessoptions(){
var mainmessage = document.createElement('div')
mainmessage.innerHTML = '<div class="overlayPageBackground"></div><div id="confirmDialog2" class="overlay" style="overflow-x: hidden; overflow-y: hidden; z-index: 1000000; top: 49.87405541561713%; left: 50%; margin-top: -57px; margin-left: -202px; opacity: 1; position: fixed; " tabindex="0"><div class="overlayBody"><div class="feedBack information"><div class="feedBackContent"><div class="feedBackBody"><a href="#" class="close" id="dialog_close_confirmDialog2" title="Cerrar" onclick="closemesagge()"></a><h2 id="dialog_title_confirmDialog2">Menú iSocial</h2><div id="dialog_content_confirmDialog1"><p>Estás a punto de acceder al menú de configuración de iSocial. Ten en cuenta que se cerrarán tus ventanas de Chat, vídeos y subidas de fotos.</p></div><div class="buttons" id="dialog_buttons_confirmDialog2"><a href="chrome-extension://apoelbpnfhemjmnfkejmnfmdfhfhblii/tuenti/optu.html" style="position:relative; top:-5px"><button class="big plane" id="dialog_button_confirmDialog_accept2" ><span><span>Continuar</span></span></button></a><a id="dialog_button_confirmDialog_cancel2" href="#" title="Cancelar" onclick="closemesagge()" >Cancelar</a></div></div></div></div></div></div>'
mainmessage.id = "mainmessage"
document.body.appendChild(mainmessage)
}

//Mensaje chat

function loadmessagechat(){
var mainmessage = document.createElement('div')
mainmessage.innerHTML = '<div class="overlayPageBackground"></div><div id="confirmDialog4" class="overlay" style="overflow-x: hidden; overflow-y: hidden; z-index: 1000000; top: 49.87405541561713%; left: 50%; margin-top: -57px; margin-left: -202px; opacity: 1; position: fixed; " tabindex="0"><div class="overlayBody"><div class="feedBack information"><div class="feedBackContent"><div class="feedBackBody"><a href="#" class="close" id="dialog_close_confirmDialog4" title="Cerrar" onclick="closemesagge()"></a><h2 id="dialog_title_confirmDialog4">Configurar chat</h2><div id="dialog_content_confirmDialog4"><p>Para acceder al menú de configuración del Chat debes ir a la sección <strong>Chat</strong>. Ten en cuenta que se cerrarán tus ventanas de Chat, vídeos y subidas de fotos.</p></div><div class="buttons" id="dialog_buttons_confirmDialog4"><a href="chrome-extension://apoelbpnfhemjmnfkejmnfmdfhfhblii/tuenti/optu.html" style="position:relative; top:-5px"><button class="big plane" id="dialog_button_confirmDialog_accept4" ><span><span>Continuar</span></span></button></a><a id="dialog_button_confirmDialog_cancel4" href="#" title="Cancelar" onclick="closemesagge()" >Cancelar</a></div></div></div></div></div></div>'
mainmessage.id = "mainmessage"
document.body.appendChild(mainmessage)
}

//Mensaje imágenes

function loadmessageimages(){
var mainmessage = document.createElement('div')
mainmessage.innerHTML = '<div class="overlayPageBackground"></div><div id="confirmDialog5" class="overlay" style="overflow-x: hidden; overflow-y: hidden; z-index: 1000000; top: 49.87405541561713%; left: 50%; margin-top: -57px; margin-left: -202px; opacity: 1; position: fixed; " tabindex="0"><div class="overlayBody"><div class="feedBack information"><div class="feedBackContent"><div class="feedBackBody"><a href="#" class="close" id="dialog_close_confirmDialog5" title="Cerrar" onclick="closemesagge()"></a><h2 id="dialog_title_confirmDialog5">Configurar imágenes</h2><div id="dialog_content_confirmDialog5"><p>Para acceder al menú de configuración de imágenes debes ir a la sección <strong>Fotos</strong>. Ten en cuenta que se cerrarán tus ventanas de Chat, vídeos y subidas de fotos.</p><p></div><div class="buttons" id="dialog_buttons_confirmDialog5"><a href="chrome-extension://apoelbpnfhemjmnfkejmnfmdfhfhblii/tuenti/optu.html" style="position:relative; top:-5px"><button class="big plane" id="dialog_button_confirmDialog_accept5" ><span><span>Continuar</span></span></button></a><a id="dialog_button_confirmDialog_cancel5" href="#" title="Cancelar" onclick="closemesagge()" >Cancelar</a></div></div></div></div></div></div>'
mainmessage.id = "mainmessage"
document.body.appendChild(mainmessage)
}


//Mensaje central

function loadmessagecentral(){
var centralmessage = document.createElement('div')
centralmessage.innerHTML = '<div class="overlayPageBackground"></div><div id="light_box" class="overlay" style="opacity: 1; z-index: 900101; position: fixed; top: 15%; left: 353px; "><div class="overlayBody lightbox"><div id="friends_importer_select_provider_lightbox" class="mod massInviter"><div class="action"><a href="#" id="close_light_box_custom" class="close" title="Cerrar" onclick="closemesaggecentral()"></a></div> <h2>Menú iSocial</h2><div class="body"><form id="event_form" method="post"><fieldset class="first"><div class="providers" id="provider_list"><div id="accessopt" class="provider gmail" onclick="loadmessageaccessoptions()"><span style="background: url(chrome-extension://apoelbpnfhemjmnfkejmnfmdfhfhblii/tuenti/images/messageimage1.png) no-repeat top left;display: block;width: 120px;height: 75px;background-position: 0 -150px;"></span></div><div id="accesschat" class="provider yahoo" onclick="loadmessagechat()"><span style="background: url(chrome-extension://apoelbpnfhemjmnfkejmnfmdfhfhblii/tuenti/images/messageimage2.png) no-repeat top left;display: block;width: 120px;height: 75px;background-position: 0 0px;"></span></div></div><div class="providers" id="provider_list"><div id="provider_logo_yahoo" class="provider yahoo"><a href="chrome-extension://apoelbpnfhemjmnfkejmnfmdfhfhblii/tuenti/share.html" onclick="closemesaggecentral()" target="_blank"><span style="background: url(chrome-extension://apoelbpnfhemjmnfkejmnfmdfhfhblii/tuenti/images/messageimage2.png) no-repeat top left;display: block;width: 120px;height: 75px;background-position: 0 -75px;"></span></a></div><div id="tv" class="provider yahoo"><a href="#" onclick="opentvclosemesagge()"><span style="background: url(chrome-extension://apoelbpnfhemjmnfkejmnfmdfhfhblii/tuenti/images/messageimage1.png) no-repeat top left;display: block;width: 120px;height: 75px; background-position: 0 -75px;"></span></a></div><div id="radiotunner" class="provider msn" onclick="openradioclosemesagge()"><span style="background: url(chrome-extension://apoelbpnfhemjmnfkejmnfmdfhfhblii/tuenti/images/messageimage1.png) no-repeat top left;display: block;width: 120px;height: 75px;background-position: 0 0px;"></span></div></div></fieldset><fieldset class="last"><span class="tip">No dudes en informarnos de cualquier error que detectes.</span></fieldset></form></div></div></div></div>'
centralmessage.id = "centralmessage"
document.body.appendChild(centralmessage)
}