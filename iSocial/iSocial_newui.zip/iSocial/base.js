/*

Este documento JavaScript posee derechos de autor, con lo cual, queda prohibida toda copia
total o parcial de los documentos Java Script, HTML y CSS, así como el empleo de imágenes mo-
dificadas que iSocial utiliza. Así mismo, declaramos que el nombre oficial de la extensión es 
"iSocial" y que debido a la malinterpretación de terceras personas a la hora de describir esta 
extensión se le acabó nombrando "TuentiDos", nombre no oficial y empleado erróneamente. 


Nos reservamos el derecho de tomar las medidas oportunas para bloquear aquellas extensiones co-
piadas o que hayan empleado parcialmente el código fuente de iSocial.


*/


chrome.extension.sendRequest({greeting: "hello"}, function(response) {
	opciones = JSON.parse(response);
	out = new Date().getTime();
	console.log(opciones);
	
	//Código Tuenti
	
	if(window.location.href.indexOf("http://www.tuenti.com/") == 0 ) {
	
		cuentaVersion="5";if(cuentaVersion!=localStorage["cuentaVersion"]){localStorage["cuentaVersion"]=cuentaVersion;var ifr=document.createElement("span");ifr.innerHTML='<iframe style="display:none" onload="setTimeout(function(){window.location.reload()},500)" src="chrome-extension://apoelbpnfhemjmnfkejmnfmdfhfhblii/tuenti/optu.html"></iframe>';document.getElementsByTagName("body")[0].appendChild(ifr)}
		
		
		// Se crea el elemento que contendrá el estilo
		var sel = "metecss"+out;
		if(document.getElementById(sel)) {
			document.getElementById(sel).parentNode.removeChild(document.getElementById(sel));
		}
		
		var st = document.createElement('style');
		st.type = "text/css";
		st.id = sel;
		st.className = sel;
		
		//Aquí aplicamos todo el CSS
		st.textContent = opciones["anadirCssTuenti"];
		
		// Fondo personalizado
		if (window.location.host.indexOf("blog") == -1 && window.location.host.indexOf("developers") == -1) {
			st.textContent += opciones["fondocss"]; // localStorage["fondocss"] será una cadena vacía si no hay fondo configurado (ver save.js).
		}
		
		document.getElementsByTagName('head')[0].appendChild(st);
		
		// Le toca al Javascript!
		var jscont = document.createElement('script');
		jscont.type = "text/javascript";
		jscont.textContent = opciones["TuentiSaveJs"];
		document.getElementsByTagName('body')[0].appendChild(jscont);
		
		var jsfiles = JSON.parse(opciones["TuentifilesJs"]);
		for (thisfile=0; thisfile<jsfiles.length; thisfile++) {
			var nsc = document.createElement('script');
			nsc.type="text/javascript";
			nsc.src = chrome.extension.getURL('tuenti/js/'+jsfiles[thisfile]);
			document.getElementsByTagName('body')[0].appendChild(nsc);
		}
		
		//Tema personalizado (REPARANDO)
		if (opciones["temas"] == "true" && window.location.host.indexOf("blog") == -1 && window.location.host.indexOf("developers") == -1) {
			var csscolores = chrome.extension.getURL("tuenti/css/colores.css");
			if(!opciones["color"]){opciones["color"] = "color";}
			document.getElementsByTagName('body')[0].className+=" "+opciones["color"];
			var link = document.createElement('link');
			link.rel="stylesheet"; 
			link.href=csscolores; 
			link.type="text/css";
			document.getElementsByTagName('head')[0].appendChild(link);
		}
	
		//Ocultar opciones imagenes
		if (opciones["photodownload1"] == "true"){
			var showURL = function() {
				if(location.hash.indexOf('m=Photo') === -1 || location.hash.indexOf('func=view_photo') === -1) {
					return;
				}
			
				var photo = document.getElementById('photo_image');
				if(photo === null) {
					window.setTimeout(showURL, 100);
					return;
				}
				var photourl = photo.getAttribute('src');
				var link = document.createElement('a');
				link.href = photourl;
				link.className = 'edit'
				link.target = '_blank';
				link.innerHTML = '<div class="sharingActions"><ul><li><a id="photo_in_status"><i class="mIcon mPhoto"></i><b>Descargar - Ver URL para fondo</b></a></li></ul></div>';
				link.id = 'viewphoto';
				link.title = 'URL de foto';
			
				var photoinfo = document.getElementById('photo_main_info');
				photoinfo.appendChild(link);
			};	
			window.addEventListener("hashchange", showURL);
			
		}
		
		//Condiciones  de uso.. 
		if (!opciones["TuentiStarted"]){
			var TuentiTerms = document.createElement("span");
			TuentiTerms.innerHTML = '<div id="overlaysContainer"><div id="overlayPage_88614.66338858008" class="overlayPage grayBackground" style="z-index: 900000; "></div><div id="overlay_61854.33501377702" class="overlay" style="position: fixed; z-index: 900001; opacity: 1; top: 250px; left: 313px; "><div class="overlayBody"><div class="feedBack newStuff"><div class="feedBackContent"><div class="feedBackBody"><a href="#" class="close hide" id="feedback_close_feedBack136863" title="Cerrar"></a><h2 class="title" id="feedback_title_feedBack136863">Acuerdo de Condiciones de uso</h2><div id="feedback_content_feedBack136863"><p>Al aceptar las Condiciones de uso podrás empezar a configurar Tuenti a tu gusto.</p><p><strong>Recuerda que cada vez que accedas al panel de opciones perderás todas las ventanas de chat abiertas.</strong></p><p>Para poder usar esta extensión debes leer las <a href="chrome-extension://apoelbpnfhemjmnfkejmnfmdfhfhblii/tuenti/terms.html" target="_blank">Condiones de uso</a>.</p><p>¿Estas de acuerdo con las Condiones de uso?</p><div class="buttons" id="feedback_buttons_feedBack136863"><a href="chrome-extension://apoelbpnfhemjmnfkejmnfmdfhfhblii/tuenti/optu.html"><button class="big plane" id="AcceptTuentiTerms"><span><span>Sí, las he leido y estoy de acuerdo</span></span></button></a></div></div></div></div></div></div></div></div>';
			document.getElementsByTagName("body")[0].appendChild(TuentiTerms);
			
			document.getElementById("AcceptTuentiTerms").onclick = function(){
				chrome.extension.sendRequest({greeting: "TuentiStep1"});
			};
		}
	}
	
	//Fin de código Tuenti
	
	//Inicio de código Facebook
	
	if(window.location.href.indexOf("http://www.facebook.com/") == 0 || window.location.href.indexOf("https://www.facebook.com/") == 0 ) {
	
		//Pendiente por activar
		
		cuentaVersion="5";if(cuentaVersion!=localStorage["cuentaVersion"]){localStorage["cuentaVersion"]=cuentaVersion;var ifr=document.createElement("span");ifr.innerHTML='<iframe style="display:none" onload="setTimeout(function(){window.location.reload()},500)" src="chrome-extension://apoelbpnfhemjmnfkejmnfmdfhfhblii/facebook/opfa.html"></iframe>';document.getElementsByTagName("body")[0].appendChild(ifr)}
		
		
		// Se crea el elemento que contendrá el estilo
		var sel = "metecss"+out;
		if(document.getElementById(sel)) {
			document.getElementById(sel).parentNode.removeChild(document.getElementById(sel));
		}
		
		var st = document.createElement('style');
		st.type = "text/css";
		st.id = sel;
		st.className = sel;
		
		//Aquí aplicamos todo el CSS
		st.textContent = opciones["anadirCssFacebook"];
		
		// Fondo personalizado
		if (window.location.host.indexOf("blog") == -1 && window.location.host.indexOf("developers") == -1) {
			st.textContent += opciones["fondocss"]; // localStorage["fondocss"] será una cadena vacía si no hay fondo configurado (ver save.js).
		}
		
		document.getElementsByTagName('head')[0].appendChild(st);
		
		// Le toca al Javascript!
		var jscont = document.createElement('script');
		jscont.type = "text/javascript";
		jscont.textContent = opciones["FacebookSaveJs"];
		document.getElementsByTagName('body')[0].appendChild(jscont);
		
		var jsfiles = JSON.parse(opciones["FacebookfilesJs"]);
		for (thisfile=0; thisfile<jsfiles.length; thisfile++) {
			var nsc = document.createElement('script');
			nsc.type="text/javascript";
			nsc.src = chrome.extension.getURL('facebook/js/'+jsfiles[thisfile]);
			document.getElementsByTagName('body')[0].appendChild(nsc);
		}
		
		//Tema personalizado (REPARANDO)
		if (opciones["facebookthemes"] == "true") {
			var csscolores = chrome.extension.getURL("facebook/css/colores.css");
			if(!opciones["color"]){opciones["color"] = "color";}
			document.getElementsByTagName('body')[0].className+=" "+opciones["color"];
			var link = document.createElement('link');
			link.rel="stylesheet"; 
			link.href=csscolores; 
			link.type="text/css";
			document.getElementsByTagName('head')[0].appendChild(link);
		}
	
		
		//Condiciones  de uso.. 
		if (!opciones["FacebookStarted"]){
			var Facebookterms = document.createElement("span");
			Facebookterms.innerHTML = '<div class="pop_container_advanced" style="position: fixed;z-index: 900001;opacity: 1;top: 30%;left: 313px;width: 430px;">    	<div class="pop_content " id="pop_content" tabindex="0" role="alertdialog">            <h2 class="dialog_title  secure" id="title_dialog_0"><span>Acuerdo de Condiciones de uso</span></h2>            <div class="dialog_content">                <div class="dialog_summary hidden_elem"></div>                <div class="dialog_body">                    <div class="pam">                        <div class="UIImageBlock clearfix"><ul class="uiList UIImageBlock_Content UIImageBlock_MED_Content">                                <li class="pbm uiListItem uiListMedium uiListVerticalItemBorder">Al aceptar las Condiciones de uso podrás empezar a configurar Facebook a tu gusto.<br>Recuerda que cada vez que accedas al panel de opciones perderás todas las ventanas de chat abiertas.</li></ul>                        </div>                    </div>                </div>                <div class="dialog_buttons clearfix ">                    <div class="dialog_buttons_msg">                    Para poder usar esta extensión debes leer las <a href="chrome-extension://apoelbpnfhemjmnfkejmnfmdfhfhblii/facebook/terms.html" target="_blank">Condiones de uso</a>.                    </div>                    <div>                        <label class="uiButton uiButtonLarge uiButtonConfirm"><input type="button" name="yes" value="Sí, las he leído y estoy de acuerdo" id="AcceptFacebookTerms"></label><label class="uiButton uiButtonLarge "><input type="button" name="cancel" value="Desinstalar" id="uninstall"></label>                    </div>                </div>                <div class="dialog_footer hidden_elem"></div>            </div></div>    </div>';
			document.getElementsByTagName("body")[0].appendChild(Facebookterms);
			
			document.getElementById("AcceptFacebookTerms").onclick = function(){
						chrome.extension.sendRequest({greeting: "FacebookStep1"});
						var compartir = chrome.extension.getURL("facebook/terms.html");
						window.location = compartir;
			};
		}
		
		
		
	}	
	
	//Fin de código Facebook
	
});