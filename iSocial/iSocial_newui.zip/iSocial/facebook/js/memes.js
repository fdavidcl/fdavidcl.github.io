function replaceByClass(className, obj) {
					if(obj.getElementsByClassName) {
						var nodes = obj.getElementsByClassName(className);
						for(i in nodes) {
							if(typeof(nodes[i].innerHTML)=="string") {
								Emotimemes(nodes[i]); 
							}
						}
					}
				}
				
			function Emotimemes(node) {
			
			node.innerHTML = node.innerHTML
			
			.replace(/&quot;\)/g, '&quot; )')
			//Reaction Faces
			.replace(/^XD+|XD+ | XD+|XD+$/gi, '<img  src="chrome-extension://apoelbpnfhemjmnfkejmnfmdfhfhblii/tuenti/images/emoticon/emoticon_1_equisde.png" style="border:none;background-color:transparent;" />')
			.replace(/^\_*^\^| \^_*\^|\^_*\^ |\^_*\^$/gi, '<img  src="chrome-extension://apoelbpnfhemjmnfkejmnfmdfhfhblii/tuenti/images/emoticon/emoticon_2_felicidad.png" style="border:none;background-color:transparent;" />')
			.replace(/^:\)+|:\)+ | :\)+|:\)+$/gi, '<img  src="chrome-extension://apoelbpnfhemjmnfkejmnfmdfhfhblii/tuenti/images/emoticon/emoticon_3_sonrisa.png" style="border:none;background-color:transparent;" />')
			.replace(/^:o+|:o+ | :o+|:o+$/gi, '<img  src="chrome-extension://apoelbpnfhemjmnfkejmnfmdfhfhblii/tuenti/images/emoticon/emoticon_4_sorpresa.png" style="border:none;background-color:transparent;" />')
			.replace(/^:p+|:p+ | :p+|:p+$/gi, '<img  src="chrome-extension://apoelbpnfhemjmnfkejmnfmdfhfhblii/tuenti/images/emoticon/emoticon_5_lengua.png" style="border:none;background-color:transparent;" />')
			.replace(/^:\(+|:\(+ | :\(+|:\(+$/gi, '<img  src="chrome-extension://apoelbpnfhemjmnfkejmnfmdfhfhblii/tuenti/images/emoticon/emoticon_6_triste.png" style="border:none;background-color:transparent;" />')
			.replace(/:mobile/gi, '<img  src="chrome-extension://apoelbpnfhemjmnfkejmnfmdfhfhblii/tuenti/images/emoticon/emoticon_7_movil.png" style="border:none;background-color:transparent;" />')
			.replace(/:iSocial/gi, '<a href="chrome-extension://apoelbpnfhemjmnfkejmnfmdfhfhblii/esshare.html" target="_blank"><img  src="chrome-extension://apoelbpnfhemjmnfkejmnfmdfhfhblii/tuenti/images/emoticon/emoticon_8_tuenti.png" style="border:none;background-color:transparent;" /></a>')
			.replace(/^:D+|:D+ | :D+|:D+$/gi, '<img  src="chrome-extension://apoelbpnfhemjmnfkejmnfmdfhfhblii/tuenti/images/emoticon/emoticon_9_sonrisota.png" style="border:none;background-color:transparent;" />')
			.replace(/^:3+|:3+ | :3+|:3+$/gi, '<img  src="chrome-extension://apoelbpnfhemjmnfkejmnfmdfhfhblii/tuenti/images/emoticon/emoticon_10_quegustito.png" style="border:none;background-color:transparent;" />')
			.replace(/:FLAGespañarepublicana/gi, '<img  src="chrome-extension://apoelbpnfhemjmnfkejmnfmdfhfhblii/tuenti/images/emoticon/emoticon_11_republicana.png" style="border:none;background-color:transparent;" />')
			.replace(/:FLAGespañanacional/gi, '<img  src="chrome-extension://apoelbpnfhemjmnfkejmnfmdfhfhblii/tuenti/images/emoticon/emoticon_12_nacional.png" style="border:none;background-color:transparent;" />')
			.replace(/:MEMEmegusta/gi, '<img  src="chrome-extension://apoelbpnfhemjmnfkejmnfmdfhfhblii/tuenti/images/emoticon/emoticon_13_megusta.png" style="border:none;background-color:transparent;" />')
			.replace(/:MEMEfuckyea/gi, '<img  src="chrome-extension://apoelbpnfhemjmnfkejmnfmdfhfhblii/tuenti/images/emoticon/emoticon_14_fuckyea.png" style="border:none;background-color:transparent;" />')
			.replace(/:MEMEyuno/gi, '<img  src="chrome-extension://apoelbpnfhemjmnfkejmnfmdfhfhblii/tuenti/images/emoticon/emoticon_15_yuno.png" style="border:none;background-color:transparent;" />')
			.replace(/:MEMEtrollface/gi, '<img  src="chrome-extension://apoelbpnfhemjmnfkejmnfmdfhfhblii/tuenti/images/emoticon/emoticon_16_trollface.png" style="border:none;background-color:transparent;" />')
			.replace(/:MEMEson/gi, '<img  src="chrome-extension://apoelbpnfhemjmnfkejmnfmdfhfhblii/tuenti/images/emoticon/emoticon_17_son.png" style="border:none;background-color:transparent;" />')
			.replace(/:MEMElol/gi, '<img  src="chrome-extension://apoelbpnfhemjmnfkejmnfmdfhfhblii/tuenti/images/emoticon/emoticon_18_lol.png" style="border:none;background-color:transparent;" />')
			.replace(/:MEMEreally/gi, '<img  src="chrome-extension://apoelbpnfhemjmnfkejmnfmdfhfhblii/tuenti/images/emoticon/emoticon_19_really.png" style="border:none;background-color:transparent;" />')
			.replace(/:MEMEfuuu/gi, '<img  src="chrome-extension://apoelbpnfhemjmnfkejmnfmdfhfhblii/tuenti/images/emoticon/emoticon_20_fuuu.png" style="border:none;background-color:transparent;" />')
			.replace(/:MEMEhappy/gi, '<img  src="chrome-extension://apoelbpnfhemjmnfkejmnfmdfhfhblii/tuenti/images/emoticon/emoticon_21_happy.png" style="border:none;background-color:transparent;" />')
			.replace(/:MEMEumm/gi, '<img  src="chrome-extension://apoelbpnfhemjmnfkejmnfmdfhfhblii/tuenti/images/emoticon/emoticon_22_umm.png" style="border:none;background-color:transparent;" />')
			.replace(/:MEMEokay/gi, '<img  src="chrome-extension://apoelbpnfhemjmnfkejmnfmdfhfhblii/tuenti/images/emoticon/emoticon_23_okay.png" style="border:none;background-color:transparent;" />')
			.replace(/:MEMEGIRLfuckyea/gi, '<img  src="chrome-extension://apoelbpnfhemjmnfkejmnfmdfhfhblii/tuenti/images/emoticon/emoticon_24_fuckyeagirl.png" style="border:none;background-color:transparent;" />')
			.replace(/:MEMEmotherofgod/gi, '<img  src="chrome-extension://apoelbpnfhemjmnfkejmnfmdfhfhblii/tuenti/images/emoticon/emoticon_25_motherofgod.png" style="border:none;background-color:transparent;" />')
			.replace(/:MEMEsadtroll/gi, '<img  src="chrome-extension://apoelbpnfhemjmnfkejmnfmdfhfhblii/tuenti/images/emoticon/emoticon_26_sadtroll.png" style="border:none;background-color:transparent;" />')
			.replace(/:MEMEyaoming/gi, '<img  src="chrome-extension://apoelbpnfhemjmnfkejmnfmdfhfhblii/tuenti/images/emoticon/emoticon_27_yaoming.png" style="border:none;background-color:transparent;" />')
			.replace(/:MEMEninja/gi, '<img  src="chrome-extension://apoelbpnfhemjmnfkejmnfmdfhfhblii/tuenti/images/emoticon/emoticon_28_ninja.png" style="border:none;background-color:transparent;" />')
			.replace(/:MEMEemm/gi, '<img  src="chrome-extension://apoelbpnfhemjmnfkejmnfmdfhfhblii/tuenti/images/emoticon/emoticon_29_emm.png" style="border:none;background-color:transparent;" />')
			.replace(/:MEMEGIRLfuuu/gi, '<img  src="chrome-extension://apoelbpnfhemjmnfkejmnfmdfhfhblii/tuenti/images/emoticon/emoticon_30_fuuugirl.png" style="border:none;background-color:transparent;" />')
			.replace(/:MEMEGIRLhappy/gi, '<img  src="chrome-extension://apoelbpnfhemjmnfkejmnfmdfhfhblii/tuenti/images/emoticon/emoticon_31_happygirl.png" style="border:none;background-color:transparent;" />')
			.replace(/:MEMEangry/gi, '<img  src="chrome-extension://apoelbpnfhemjmnfkejmnfmdfhfhblii/tuenti/images/emoticon/emoticon_32_angry.png" style="border:none;background-color:transparent;" />')
			.replace(/:MEMEforeveralone/gi, '<img  src="chrome-extension://apoelbpnfhemjmnfkejmnfmdfhfhblii/tuenti/images/emoticon/emoticon_33_foreveralone.png" style="border:none;background-color:transparent;" />')
			.replace(/:MEMEchallengeaccepted/gi, '<img  src="chrome-extension://apoelbpnfhemjmnfkejmnfmdfhfhblii/tuenti/images/emoticon/emoticon_34_challengeaccepted.png" style="border:none;background-color:transparent;" />')
			.replace(/:MEMEwhynot/gi, '<img  src="chrome-extension://apoelbpnfhemjmnfkejmnfmdfhfhblii/tuenti/images/emoticon/emoticon_35_whynot.png" style="border:none;background-color:transparent;" />')
			.replace(/:MEMEtrolldad/gi, '<img  src="chrome-extension://apoelbpnfhemjmnfkejmnfmdfhfhblii/tuenti/images/emoticon/emoticon_36_trolldad.png" style="border:none;background-color:transparent;" />')
			.replace(/:MEMEraisins/gi, '<img  src="chrome-extension://apoelbpnfhemjmnfkejmnfmdfhfhblii/tuenti/images/emoticon/emoticon_37_raisins.png" style="border:none;background-color:transparent;" />')
			.replace(/:MEMEpukerainbows/gi, '<img  src="chrome-extension://apoelbpnfhemjmnfkejmnfmdfhfhblii/tuenti/images/emoticon/emoticon_38_pukerainbows.png" style="border:none;background-color:transparent;" />')
			.replace(/:MEMEcool/gi, '<img  src="chrome-extension://apoelbpnfhemjmnfkejmnfmdfhfhblii/tuenti/images/emoticon/emoticon_39_cool.png" style="border:none;background-color:transparent;" />')
			.replace(/:MEME2GIRLfuuu/gi, '<img  src="chrome-extension://apoelbpnfhemjmnfkejmnfmdfhfhblii/tuenti/images/emoticon/emoticon_40_fuuugirl2.png" style="border:none;background-color:transparent;" />')
			.replace(/:MEMEomf/gi, '<img  src="chrome-extension://apoelbpnfhemjmnfkejmnfmdfhfhblii/tuenti/images/emoticon/emoticon_41_omf.png" style="border:none;background-color:transparent;" />')
			.replace(/:MEMEwhy/gi, '<img  src="chrome-extension://apoelbpnfhemjmnfkejmnfmdfhfhblii/tuenti/images/emoticon/emoticon_42_why.png" style="border:none;background-color:transparent;" />')
			.replace(/:MEMEneveralone/gi, '<img  src="chrome-extension://apoelbpnfhemjmnfkejmnfmdfhfhblii/tuenti/images/emoticon/emoticon_43_neveralone.png" style="border:none;background-color:transparent;" />')
			.replace(/:MEMEkiddingme/gi, '<img  src="chrome-extension://apoelbpnfhemjmnfkejmnfmdfhfhblii/tuenti/images/emoticon/emoticon_44_kiddingme.png" style="border:none;background-color:transparent;" />')
			.replace(/:MEMEsuspicious/gi, '<img  src="chrome-extension://apoelbpnfhemjmnfkejmnfmdfhfhblii/tuenti/images/emoticon/emoticon_45_suspicious.png" style="border:none;background-color:transparent;" />')
			.replace(/:MEMEGIRLtroll/gi, '<img  src="chrome-extension://apoelbpnfhemjmnfkejmnfmdfhfhblii/tuenti/images/emoticon/emoticon_46_trollgirl.png" style="border:none;background-color:transparent;" />')
			.replace(/:MEMEinglip/gi, '<img  src="chrome-extension://apoelbpnfhemjmnfkejmnfmdfhfhblii/tuenti/images/emoticon/emoticon_47_inglip.png" style="border:none;background-color:transparent;" />')
			.replace(/:MEMEitsfree/gi, '<img  src="chrome-extension://apoelbpnfhemjmnfkejmnfmdfhfhblii/tuenti/images/emoticon/emoticon_48_itsfree.png" style="border:none;background-color:transparent;" />')
			.replace(/:MEMEmentira/gi, '<img  src="chrome-extension://apoelbpnfhemjmnfkejmnfmdfhfhblii/tuenti/images/emoticon/emoticon_49_mentira.png" style="border:none;background-color:transparent;" />')
			.replace(/:MEMEfeellikeasir/gi, '<img  src="chrome-extension://apoelbpnfhemjmnfkejmnfmdfhfhblii/tuenti/images/emoticon/emoticon_50_feellikeasir.png" style="border:none;background-color:transparent;" />')
			.replace(/:MEMEcereales/gi, '<img  src="chrome-extension://apoelbpnfhemjmnfkejmnfmdfhfhblii/tuenti/images/emoticon/emoticon_51_cereales.png" style="border:none;background-color:transparent;" />')
			.replace(/:MEMEbetterthanexpected/gi, '<img  src="chrome-extension://apoelbpnfhemjmnfkejmnfmdfhfhblii/tuenti/images/emoticon/emoticon_52_betterthanexpected.png" style="border:none;background-color:transparent;" />')
			.replace(/:MEMEawwyea/gi, '<img  src="chrome-extension://apoelbpnfhemjmnfkejmnfmdfhfhblii/tuenti/images/emoticon/emoticon_53_awwyea.png" style="border:none;background-color:transparent;" />')
			.replace(/:MEMEGIRLfapfap/gi, '<img  src="chrome-extension://apoelbpnfhemjmnfkejmnfmdfhfhblii/tuenti/images/emoticon/emoticon_54_fapfapgirl.png" style="border:none;background-color:transparent;" />')
			.replace(/:MEMEfapfap/gi, '<img  src="chrome-extension://apoelbpnfhemjmnfkejmnfmdfhfhblii/tuenti/images/emoticon/emoticon_55_fapfap.png" style="border:none;background-color:transparent;" />')
			.replace(/:MEMEtrolledtroll/gi, '<img  src="chrome-extension://apoelbpnfhemjmnfkejmnfmdfhfhblii/tuenti/images/emoticon/emoticon_56_trolledtroll.png" style="border:none;background-color:transparent;" />')
			.replace(/:MEME2raisins/gi, '<img  src="chrome-extension://apoelbpnfhemjmnfkejmnfmdfhfhblii/tuenti/images/emoticon/emoticon_57_raisins2.png" style="border:none;background-color:transparent;" />')
			.replace(/:MEMEjodete/gi, '<img  src="chrome-extension://apoelbpnfhemjmnfkejmnfmdfhfhblii/tuenti/images/emoticon/emoticon_58_jodete.png" style="border:none;background-color:transparent;" />')
			.replace(/:MEMEitssomething/gi, '<img  src="chrome-extension://apoelbpnfhemjmnfkejmnfmdfhfhblii/tuenti/images/emoticon/emoticon_59_itssomething.png" style="border:none;background-color:transparent;" />')
			.replace(/:MEMEpokerface/gi, '<img  src="chrome-extension://apoelbpnfhemjmnfkejmnfmdfhfhblii/tuenti/images/emoticon/emoticon_60_pokerface.png" style="border:none;background-color:transparent;" />')
			.replace(/:MEMEupset/gi, '<img  src="chrome-extension://apoelbpnfhemjmnfkejmnfmdfhfhblii/tuenti/images/emoticon/emoticon_61_upset.png" style="border:none;background-color:transparent;" />')
			.replace(/:MEMEuf/gi, '<img  src="chrome-extension://apoelbpnfhemjmnfkejmnfmdfhfhblii/tuenti/images/emoticon/emoticon_62_uf.png" style="border:none;background-color:transparent;" />')
			//Pendiente por añadir más..
			
			.replace(/^;\)+|;\)+ | ;\)+|;\)+$/gi, '<img  src="chrome-extension://apoelbpnfhemjmnfkejmnfmdfhfhblii/tuenti/images/emoticon/emoticon_63_guino.png" style="border:none;background-color:transparent;" />')
			.replace(/^:\8+|:\8+ | :\8+|:\8+$/gi, '<img  src="chrome-extension://apoelbpnfhemjmnfkejmnfmdfhfhblii/tuenti/images/emoticon/emoticon_64_verguenza.png" style="border:none;background-color:transparent;" />')
			
			
				}
				
				function commonInsert(obj) {
					if(typeof(obj)=="object") {
						replaceByClass('mod status', obj); //Estados de la portada
						replaceByClass('statusBox', obj); //Estados de páginas
						replaceByClass('status', obj); //Estados de perfiles
						replaceByClass('text', obj); //Comentarios
						replaceByClass('mod mainInfo', obj); //Títulos paginas-eventos
						replaceByClass('itemInfoSearch', obj); //Titulos busquedas 
					}
				}

function nodeInserted(event) {
    commonInsert(event.target);
}



commonInsert(document);

document.addEventListener('DOMNodeInserted', function(event) {

        commonInsert(event.target);

    }, false);